package alphabetsoup;


import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author aitor.martinezparente
 */
public class AlphabetSoupApp {
    
    private ArrayList <AlphabetSoup> souplist = new ArrayList<AlphabetSoup>();

    public ArrayList<AlphabetSoup> getAlphabetsoup() {
        return souplist;
    }

    public void setAlphabetsoup(ArrayList<AlphabetSoup> alphabetsoup) {
        this.souplist = alphabetsoup;
    }

    public AlphabetSoupApp() {
        
    }
    
    public selectSoup(){
        
    }

    public 
    
    
    
}
